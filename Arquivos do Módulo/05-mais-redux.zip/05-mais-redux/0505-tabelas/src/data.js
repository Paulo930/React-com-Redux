export default [
  {
    id: 1,
    name: 'Camiseta',
    color: 'azul',
    price: 25,
  },
  {
    id: 2,
    name: 'Camiseta',
    color: 'preta',
    price: 25,
  },
  {
    id: 3,
    name: 'Bermuda',
    color: 'preta',
    price: 35,
  },
  {
    id: 4,
    name: 'Saia',
    color: 'preta',
    price: 22,
  },
  {
    id: 5,
    name: 'Camisa Polo',
    color: 'azul',
    price: 42,
  },
  {
    id: 6,
    name: 'Vestido',
    color: 'azul',
    price: 60,
  },
  {
    id: 7,
    name: 'Camisa',
    color: 'rosa',
    price: 30,
  },
];
